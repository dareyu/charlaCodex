import { Button } from './components/button/button';
import styles from './App.module.css';
function App() {
    return (
        <div className={styles.gridContainer}>
            <div className={styles.gridItem}>
                <h1 className={styles.title}>Hola Mundo</h1>
                <Button label="BUTTON" color="primary" fullwidth={true} size="large" />
            </div>
        </div>
    );
}

export default App;
