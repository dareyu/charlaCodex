import { createBoard } from '@wixc3/react-board';
import App from '../../App';

export default createBoard({
    name: 'App',
    Board: () => <App />,
    isSnippet: true,
    environmentProps: {
        windowWidth: 375,
        windowHeight: 667,
        canvasWidth: 811,
        canvasHeight: 698,
    },
});
