import styles from './button.module.css';

interface ButtonProps {
  label: string;
  color?: 'primary' | 'secondary';
  fullwidth?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export const Button = ({
  label,
  color = 'primary',
  fullwidth = false,
  size = 'medium',
}: ButtonProps) => {
  let classNames = `${styles.btn} ${styles['btn-' + color]} ${styles[size]}`;
  if (fullwidth) classNames += ` ${styles.fullwidth}`;
  return <button className={classNames}>{label}</button>;
};
